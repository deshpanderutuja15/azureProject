# Databricks notebook source

import os
import sys

print(os.getcwd())

project_path = os.path.join(os.getcwd(), "..", "..")


print(project_path)


#
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

df=spark.read.format("parquet")\
    .load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/Dimuser")

# COMMAND ----------

df.display()

# COMMAND ----------

df_user=spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/data")\
    .option("SchemaEvolutionMode","rescue")\
    .load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/Dimuser")

# COMMAND ----------

# DBTITLE 1,Cell 4
display(df_user, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/checkpoint23")



display(
    spark.read.format("parquet")
        .load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/Dimuser")
)

# COMMAND ----------

df_user=df_user.withColumn("user_name",upper(col("user_name")))
display(df_user, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/checkpoint19")

# COMMAND ----------

# /Workspace/Users/deshpandern1503_outlook.com#ext#@deshpandern1503outlook.onmicrosoft.com/Drafts/spotify_dab/utils/trans_utils.py



from spotify_dab.utils.trans_utils import var_A

# COMMAND ----------



import os
import sys




if project_path not in sys.path:
    sys.path.insert(0, project_path)


print(project_path)

from utils.trans_utils import dropcolumn

obj = dropcolumn()
df_clean = obj.dropColumns(df_user, "_rescued_data")
display(df_clean, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/checkpoint25")


# COMMAND ----------

from utils.trans_utils import dropcolumn

# COMMAND ----------

df_clean=df_clean.dropDuplicates(["_rescued_data"])
display(df_clean)


# COMMAND ----------

df_user.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/checkpoint26")\
    .trigger(once=True)\
    .start("abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/data")


# COMMAND ----------

    df_user.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/checkpoint27")\
    .option("path","abfss://silver@storageazureprojectr.dfs.core.windows.net/Dimuser/data")\
    .trigger(once=True)\
    .toTable("databricksazureproj.silver.Dimuser")
    

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricksazureproj.silver.Dimuser

# COMMAND ----------

df_art=spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@storageazureprojectr.dfs.core.windows.net/DimArtist/data")\
    .option("SchemaEvolutionMode","rescue")\
    .load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/DimArtist")
display(df_art, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimArtist/checkpoint11")




# COMMAND ----------

df_art=df_art.withColumn("artist_name",upper(col("artist_name")))
display(df_art, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimArtist/checkpoint24")

from utils.trans_utils import dropcolumn
obj = dropcolumn()
df_clean = obj.dropColumns(df_art, "_rescued_data")

display(df_clean, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimArtist/checkpoint25")

# COMMAND ----------

df_clean=df_clean.dropDuplicates(["artist_name"])
display(df_clean, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimArtist/checkpoint35")

# COMMAND ----------

df_clean.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimArtist/checkpoint27")\
    .trigger(once=True)\
    .toTable("databricksazureproj.silver.DimArtist")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricksazureproj.silver.DimArtist

# COMMAND ----------

df_track=spark.readStream.format("cloudFiles")\
.option("cloudFiles.format", "parquet")\
.option("SchemaEvolutionMode","rescue")\
.option("checkpointLocation", "abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint")\
.option("cloudFiles.schemaLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint22")\
.load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/DimTrack")

display(df_track, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint23")



# COMMAND ----------

df_track=df_track.withColumn("album_name",upper(col("album_name")))
display(df_track, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint29")


# COMMAND ----------

df_track=dropcolumn().dropColumns(df_track, "_rescued_data")
display(df_track, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint24")
df_track=df_track.dropDuplicates(["track_name"])
display(df_track, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint26")





# COMMAND ----------

# DBTITLE 1,Cell 22
from pyspark.sql.functions import col, regexp_replace

df_track = df_track.withColumn("track_name", regexp_replace(col("track_name"), "-", "  "))
display(df_track, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint27")

# COMMAND ----------

df_track=df_track.withColumn("duration_severity",when(col("duration_sec")>300,"High")\
                             .when(col("duration_sec")>120,"Medium")\
                             .when(col("duration_sec")>60,"Low")\
                             .otherwise("Very Low"))
display(df_track, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint21")


# COMMAND ----------

df_track.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint22")\
    .option("path","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/delta_path")\
    .trigger(once=True)\
    .toTable("databricksazureproj.silver.DimTrack")

# COMMAND ----------

df_track.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/checkpoint202307")\
    .trigger(once=True)\
    .start("abfss://silver@storageazureprojectr.dfs.core.windows.net/DimTrack/delta_path")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricksazureproj.silver.DimTrack

# COMMAND ----------

df_date=spark.readStream.format("cloudFiles")\
.option("cloudFiles.format", "parquet")\
.option("SchemaEvolutionMode","rescue")\
.option("checkpointLocation", "abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/checkpoint2023071")\
.option("cloudFiles.schemaLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/checkpoint2023077")\
.load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/DimDate")

display(df_date, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/checkpoint2023017")

# COMMAND ----------

df_date=dropcolumn().dropColumns(df_date,"_rescued_data")
display(df_date, checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/checkpoint20263078")


# COMMAND ----------

df_date.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/checkpoint202617")\
    .toTable("databricksazureproj.silver.DimDate")


   

# COMMAND ----------

df_date.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/checkpoint2062717")\
    .start("abfss://silver@storageazureprojectr.dfs.core.windows.net/DimDate/data")

# COMMAND ----------

df_factStream=spark.readStream.format("cloudFiles")\
.option("cloudFiles.format", "parquet")\
.option("SchemaEvolutionMode","rescue")\
.option("checkpointLocation", "abfss://silver@storageazureprojectr.dfs.core.windows.net/FactStream/checkpoint11")\
.option("cloudFiles.schemaLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/FactStream/checkpoint21")\
.load("abfss://bronze@storageazureprojectr.dfs.core.windows.net/FactStream")


# COMMAND ----------

display(df_factStream,checkpointLocation= "abfss://silver@storageazureprojectr.dfs.core.windows.net/FactStream/checkpoint19")

# COMMAND ----------

df_factStream=dropcolumn().dropColumns(df_factStream,"_rescued_data")
display(df_factStream,checkpointLocation="abfss://silver@storageazureprojectr.dfs.core.windows.net/FactStream/checkpoint22")

# COMMAND ----------

df_factStream.writeStream.format("delta")\
    .outputMode("append")\
    .option("path","abfss://silver@storageazureprojectr.dfs.core.windows.net/FactStream/data")\
    .option("checkpointLocation","abfss://silver@storageazureprojectr.dfs.core.windows.net/FactStream/checkpoint2'3")\
    .toTable("databricksazureproj.silver.FactStream")
